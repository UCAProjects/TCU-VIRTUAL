<form>
	<label for="uploadedAprobacion">Adjuntar carta de conclusión del TCU emitida por la institución responsable</label>
	<br><br>
	<input name="uploadedAprobacion" type="file" />
	<br>
	<div class="modal-footer">
		<button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fas fa-times"></i> Cerrar</button>
		<button type="button" class="btn btn-segundary"> <i class="far fa-paper-plane"></i> Enviar</button>
	</div>
</div>
</form>
