﻿<!doctype html>
<html class="no-js" lang="">
    <head>
        <title>
        	Registro  <!--  MODIFICAR TITLE -->
        </title>
    </head>
    <body>

    	<?php 
    		include '../header.php'
    	?>
        

      <!--  CODGO DE LA PAGINA -->


        <?php 
        	include '../footer.php'
        ?>
    </body>
</html>
